# MinionPlugin

This is a Minion Plugin for PocketMine-MP.

## Features:
- Automated minions
- Easy to use commands

## Installation:
1. Download the `.phar` file from Poggit.
2. Place it in the `plugins/` folder.
3. Restart your server.

Enjoy!